﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MyClassLibraryPR5;

namespace PR5
{
    class Program
    {
        static void Main(string[] args)
        {
            Car JOY = new Car();
            JOY.marka = ("Audi");
            JOY.gosnomer = ("A343XC");
            JOY.probeg = (12000);

            JOY.Show();
            Console.ReadKey();
        }
    }
}
